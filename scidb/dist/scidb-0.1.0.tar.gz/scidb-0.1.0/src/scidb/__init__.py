"""
SciStack: Scientific Data Versioning Framework

A lightweight database framework for scientific computing that provides:
- Type-safe serialization of numpy arrays, DataFrames, and custom types
- Automatic content-based versioning
- Flexible metadata-based addressing
- DuckDB storage for data and lineage (via SciDuck)

Example:
    from scidb import configure_database, BaseVariable
    import numpy as np

    # Setup (single DuckDB file for data + lineage, auto-registers types)
    db = configure_database("experiment.duckdb", ["subject", "session"])

    class RawSignal(BaseVariable):
        schema_version = 1

    # Save/load
    RawSignal.save(np.array([1, 2, 3]), subject=1, session="A")
    raw = RawSignal.load(subject=1, session="A")
"""

from .database import configure_database, get_database, get_user_id
from .log import Log
from .exceptions import (
    AmbiguousParamError,
    AmbiguousVersionError,
    DatabaseNotConfiguredError,
    NotFoundError,
    NotRegisteredError,
    ReservedMetadataKeyError,
    SciStackError,
)

# Batch execution (Layer 2 — DB-backed, no lineage)
from .foreach import for_each
from .fixed import Fixed
from .variant import Variant
from .merge import Merge
from .column_selection import ColumnSelection
from .colname import ColName
from .each_of import EachOf
from .foreach_config import ForEachConfig

# From scifor (Layer 1)
from scifor import Col, set_schema, get_schema, PathInput, PathOutput

from .variable import BaseVariable
from .filters import raw_sql, schema_key
from .constant import Constant, constant
from .exclusions import exclude_schema, include_schema, list_exclusions
from .discover import (
    DiscoveryResult,
    ModuleError,
    ModuleExports,
    PackageResult,
    discover_module,
    scan_package,
    scan_project,
)

from scilineage import manual

__version__ = "0.1.0"

__all__ = [
    # Core classes
    "BaseVariable",
    "Constant",
    "constant",
    # Discovery
    "scan_project",
    "scan_package",
    "discover_module",
    "DiscoveryResult",
    "PackageResult",
    "ModuleExports",
    "ModuleError",
    # Configuration
    "configure_database",
    "get_database",
    "get_user_id",
    # Logging
    "Log",
    # Batch execution
    "for_each",
    "Fixed",
    "Variant",
    "Merge",
    "ColumnSelection",
    "ColName",
    "EachOf",
    "ForEachConfig",
    "PathInput",
    "PathOutput",
    # Standalone / DataFrame support
    "Col",
    "set_schema",
    "get_schema",
    # Filter utilities
    "raw_sql",
    "schema_key",
    # Schema exclusions
    "exclude_schema",
    "include_schema",
    "list_exclusions",
    # Exceptions
    "SciStackError",
    "NotRegisteredError",
    "NotFoundError",
    "DatabaseNotConfiguredError",
    "ReservedMetadataKeyError",
    "AmbiguousVersionError",
    "AmbiguousParamError",
]
